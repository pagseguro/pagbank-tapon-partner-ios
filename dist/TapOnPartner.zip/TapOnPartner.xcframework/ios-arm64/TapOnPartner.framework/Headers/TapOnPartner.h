//
//  TapOnPartner.h
//  TapOnPartner
//
//  Created by Hildequias Junior on 22/05/25.
//

#import <Foundation/Foundation.h>

//! Project version number for TapOnPartner.
FOUNDATION_EXPORT double TapOnPartnerVersionNumber;

//! Project version string for TapOnPartner.
FOUNDATION_EXPORT const unsigned char TapOnPartnerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TapOnPartner/PublicHeader.h>


